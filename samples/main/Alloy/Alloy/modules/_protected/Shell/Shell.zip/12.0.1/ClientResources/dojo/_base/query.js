//>>built
define("dojo/_base/query",["../query","./NodeList"],function(_1){return _1;});